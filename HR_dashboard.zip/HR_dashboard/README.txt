1) HR_ANALYTICS_DASHBOARD.twbx is Tableau file where you can find the Dashboard (Dashbaord name - Dasboard_HR_Analytics)
2) Dashboard can be interacted with Education of employees(Dropdown field) - Interactive field
3) Click on pie chart to understand the attrition by each department(Interactive field - changes the whole dashboard accordingly)
4) Explore the Number of employees bar chart by Age groups with bin size(dipicts Age)



** I have published the file to view Dashboard in browser for simplying the process. Please find link below **
There can be little difference in Original file and published file in Dashboard organisation - if possible, please prefer to look at tableau file

Link : - https://public.tableau.com/app/profile/sandeep.kumar.yedla/viz/SKY_16914606135250/HRAnalytics#1 